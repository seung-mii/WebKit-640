package org.comstudy.myweb.saram.model;

public class SaramDAO {

}
