package org.comstudy.myweb.board.model;

public class BoardDAO {

}
